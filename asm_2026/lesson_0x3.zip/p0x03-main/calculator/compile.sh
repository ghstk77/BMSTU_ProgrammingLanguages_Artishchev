#!/bin/bash 

nasm -f elf64 main.nasm && gcc -static main.o