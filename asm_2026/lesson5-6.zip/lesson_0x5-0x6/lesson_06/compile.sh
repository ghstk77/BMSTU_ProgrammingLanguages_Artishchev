#!/bin/bash 

gcc -c main.c && nasm -f elf64 external.nasm && gcc main.o external.o -o output.elf 