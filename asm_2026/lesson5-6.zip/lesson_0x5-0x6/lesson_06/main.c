#include <stdio.h>
#include <stdlib.h>

void test_me(){
	printf("dead beef");
}

// dst - rdi, src - rsi, num_bytes - rdx
void my_memcpy(void* dst, void* src, unsigned long long	num_bytes);

int main()
{
	unsigned char* ptr1 = malloc(0x10);
	unsigned char* ptr2 = malloc(0x10);

	for (int i = 0; i< 0x10; ++i){
		ptr1[i] = 0xde;
	}

	for (int i = 0; i< 0x10; ++i){
		ptr2[i] = 0;
	}

	printf("initial ptr1 = %p\r\n", ptr1);
	
	for (int i = 0; i < 0x10; ++i) {
		printf("%x ", ptr1[i]);
	}
	printf("\r\n");

	printf("initial ptr2 = %p\r\n", ptr2);
	
	for (int i = 0; i < 0x10; ++i) {
		printf("%x ", ptr2[i]);
	}

	printf("\r\n");

	my_memcpy(ptr2, ptr1, 0x10);

	printf("after copy ptr2 = %p\r\n", ptr2);
	
	for (int i = 0; i < 0x10; ++i) {
		printf("%x ", ptr2[i]);
	}

	printf("\r\n");

	
	return 0;
}