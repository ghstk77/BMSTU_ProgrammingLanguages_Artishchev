[bits 64]
global my_memcpy

section .text

my_memcpy:
	push rbp 
	mov rbp, rsp

	mov rcx, rdx
	rep movsb 
	
	mov rsp, rbp
	pop rbp
	ret
