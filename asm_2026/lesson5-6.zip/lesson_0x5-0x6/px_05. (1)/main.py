from subprocess import CalledProcessError, run
from random import choice, randint, shuffle
from difflib import ndiff
from string import ascii_lowercase, hexdigits
from itertools import permutations
from itertools import combinations
from string import ascii_letters, digits

try:
    print("Compiling sources...")

    run(["nasm", "-f", "elf64", "main.nasm"], check=True, capture_output=True)
    run(["gcc", "-static", "main.o", "main.c"], check=True, capture_output=True)

except CalledProcessError as e:
    stderr = e.stderr.decode().strip()
    stdout = e.stdout.decode().strip()
    print(f"Compiling error ({e.cmd})")
    if stderr:
        print(stderr)
    if stdout:
        print(stdout)

    exit(1)

try:
    print("Checking...")

    count = randint(10, 15)
    values = [randint(10, 99) for _ in range(count)]

    etalon = ' '.join(map(str, sorted(values)))

    stdin = f"{len(values)}\n{' '.join(map(str, values))}"
    print(f"Input:\n{stdin}")

    p = run(["./a.out"], input=stdin.encode(), check=True, capture_output=True)

    stdout = p.stdout.decode().lower().strip()

    print("Application output:")
    print(stdout)

    print(f"Expected: {etalon}")

    if stdout != etalon:
        print("Output not matched:")

        result = ndiff(
            stdout.splitlines(keepends=True), etalon.splitlines(keepends=True)
        )

        print("\n".join(result))

        exit(1)
    else:
        print("Output matched!")


except CalledProcessError as e:
    stderr = e.stderr.decode().strip()
    stdout = e.stdout.decode().strip()
    print(f"Checking error ({e.cmd})")
    if stderr:
        print(stderr)
    if stdout:
        print(stdout)
