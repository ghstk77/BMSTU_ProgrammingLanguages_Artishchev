from subprocess import CalledProcessError, run
from random import choice
from difflib import ndiff
from string import hexdigits

try:
    print("Compiling sources...")

    run(["nasm", "-f", "elf64", "main.nasm"], check=True, capture_output=True)
    run(["gcc", "-static", "main.o"], check=True, capture_output=True)

except CalledProcessError as e:
    stderr = e.stderr.decode().strip()
    stdout = e.stdout.decode().strip()
    print(f"Compiling error ({e.cmd})")
    if stderr:
        print(stderr)
    if stdout:
        print(stdout)

    exit(1)

try:
    print("Checking...")

    h = list(set(hexdigits.lower()))
    num = ''.join(choice(h) for _ in range(16))

    stdin = f"{num}"
    print(f"Input: {stdin}")

    p = run(["./a.out"], input=stdin.encode(), check=True, capture_output=True)

    stdout = p.stdout.decode().lower().strip()

    print("Application output:")
    print(stdout)

    etalon = ''.join(chr(ord('a') + i) for i in map(lambda x: int(x, 16), num))

    print(f"Expected: {etalon}")

    if stdout != etalon:
        print("Output not matched:")

        result = ndiff(
            stdout.splitlines(keepends=True), etalon.splitlines(keepends=True)
        )

        print("".join(result))

        exit(1)
    else:
        print("Output matched!")


except CalledProcessError as e:
    stderr = e.stderr.decode().strip()
    stdout = e.stdout.decode().strip()
    print(f"Checking error ({e.cmd})")
    if stderr:
        print(stderr)
    if stdout:
        print(stdout)
